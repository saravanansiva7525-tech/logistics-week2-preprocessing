"""
Week 2 Task — Data Collection, Cleaning, and Preprocessing for Logistics Analysis
Dataset: DataCo Smart Supply Chain (sample) — see generate_sample_data.py for provenance.

Run:
    python3 preprocessing.py
"""
import pandas as pd
from sklearn.preprocessing import MinMaxScaler, StandardScaler

pd.set_option("display.width", 100)
pd.set_option("display.max_columns", 10)

INPUT_PATH = "data/dataco_supply_chain_sample.csv"
OUTPUT_PATH = "data/logistics_clean.csv"


def load_and_inspect(path):
    df = pd.read_csv(path, parse_dates=["Order Date"])
    print("=" * 60)
    print("STEP 1: RAW DATA INSPECTION")
    print("=" * 60)
    print(f"Shape: {df.shape}")
    print("\nMissing values per column (raw):")
    print(df.isnull().sum().sort_values(ascending=False))
    return df


def drop_empty_columns(df, threshold=50):
    missing_pct = df.isnull().mean() * 100
    cols_to_drop = missing_pct[missing_pct > threshold].index.tolist()
    print("\n" + "=" * 60)
    print("STEP 2: DROP STRUCTURALLY EMPTY COLUMNS (>50% missing)")
    print("=" * 60)
    print(f"Dropping: {cols_to_drop}")
    return df.drop(columns=cols_to_drop)


def impute_missing(df):
    print("\n" + "=" * 60)
    print("STEP 3: IMPUTE REMAINING MISSING VALUES")
    print("=" * 60)
    before = df["Days for shipping (real)"].isnull().sum()
    df["Days for shipping (real)"] = (
        df.groupby("Shipping Mode")["Days for shipping (real)"]
        .transform(lambda x: x.fillna(x.median()))
    )
    print(f"'Days for shipping (real)': {before} nulls -> "
          f"{df['Days for shipping (real)'].isnull().sum()} nulls (grouped median imputation)")

    if "Customer Zipcode" in df.columns:
        before = df["Customer Zipcode"].isnull().sum()
        df["Customer Zipcode"] = df["Customer Zipcode"].fillna(df["Customer Zipcode"].mode()[0])
        print(f"'Customer Zipcode': {before} nulls -> "
              f"{df['Customer Zipcode'].isnull().sum()} nulls (mode imputation)")
    return df


def cap_outliers_iqr(series, k=1.5):
    q1, q3 = series.quantile(0.25), series.quantile(0.75)
    iqr = q3 - q1
    lower, upper = q1 - k * iqr, q3 + k * iqr
    return series.clip(lower, upper)


def handle_outliers(df):
    print("\n" + "=" * 60)
    print("STEP 4: OUTLIER DETECTION & CAPPING (IQR method)")
    print("=" * 60)
    for col in ["Sales", "Order Item Quantity", "Order Profit Per Order"]:
        q1, q3 = df[col].quantile(0.25), df[col].quantile(0.75)
        iqr = q3 - q1
        lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
        n_outliers = ((df[col] < lower) | (df[col] > upper)).sum()
        df[col] = cap_outliers_iqr(df[col])
        print(f"{col}: {n_outliers} outliers capped to [{lower:.2f}, {upper:.2f}]")
    return df


def scale_features(df):
    print("\n" + "=" * 60)
    print("STEP 5: SCALING")
    print("=" * 60)
    minmax_cols = ["Order Item Quantity", "Days for shipping (real)"]
    standard_cols = ["Sales", "Order Profit Per Order"]

    print(f"Min-Max scaling -> {minmax_cols}")
    df[minmax_cols] = MinMaxScaler().fit_transform(df[minmax_cols])

    print(f"Standard scaling -> {standard_cols}")
    df[standard_cols] = StandardScaler().fit_transform(df[standard_cols])
    return df


def main():
    df = load_and_inspect(INPUT_PATH)
    raw_shape = df.shape
    raw_missing_rows = df.isnull().any(axis=1).sum()

    df = drop_empty_columns(df)
    df = impute_missing(df)
    df = handle_outliers(df)
    df = scale_features(df)

    print("\n" + "=" * 60)
    print("STEP 6: BEFORE / AFTER SUMMARY")
    print("=" * 60)
    print(f"{'Metric':<45}{'Before':>10}{'After':>10}")
    print(f"{'Columns':<45}{raw_shape[1]:>10}{df.shape[1]:>10}")
    print(f"{'Rows with any missing value':<45}{raw_missing_rows:>10}{df.isnull().any(axis=1).sum():>10}")

    df.to_csv(OUTPUT_PATH, index=False)
    print(f"\nCleaned dataset written to: {OUTPUT_PATH}")
    print(f"Final shape: {df.shape}")

    print("\nFinal missing-value check:")
    print(df.isnull().sum())


if __name__ == "__main__":
    main()
