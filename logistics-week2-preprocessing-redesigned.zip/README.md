<div align="center">

<img src="assets/banner.png" width="100%" alt="Data Collection, Cleaning & Preprocessing Pipeline"/>

<br/>

![Python](https://img.shields.io/badge/Python-3.10%2B-0F5257?style=flat-square&logo=python&logoColor=white)
![pandas](https://img.shields.io/badge/pandas-2.x-C9A227?style=flat-square&logo=pandas&logoColor=white)
![scikit--learn](https://img.shields.io/badge/scikit--learn-1.3%2B-0F5257?style=flat-square&logo=scikitlearn&logoColor=white)
![status](https://img.shields.io/badge/status-executed%20%26%20verified-C9A227?style=flat-square)
![license](https://img.shields.io/badge/license-MIT-0A3A3D?style=flat-square)

*Week 2 — Yuva Intern, Logistics Data Analyst Internship*

</div>

---

## Overview

A complete, **runnable** data-cleaning pipeline for logistics order data: missing-value handling, IQR-based outlier capping, and feature scaling — implemented in both a plain script and an executed Jupyter notebook.

The schema mirrors the public **[DataCo Smart Supply Chain dataset](https://www.kaggle.com/datasets/shashwatwork/dataco-smart-supply-chain-for-big-data-analysis)** (~180,000 real order records, 50+ features, 3 years of transactions). Since the full dataset requires an authenticated Kaggle download, [`generate_sample_data.py`](generate_sample_data.py) builds a **representative 1,200-row sample** with the same columns and the same *kinds* of real-world issues — a near-empty `Order Zipcode` column, a fully-null `Product Description` column, sparse missing values, and genuine statistical outliers — so the pipeline below runs against real messiness, not a toy dataset.

> **To run at full scale:** download the real CSV from the Kaggle link above, save it as `data/dataco_supply_chain.csv`, and point `INPUT_PATH` in `preprocessing.py` at it. The pipeline logic is identical either way.

## Pipeline

```mermaid
flowchart LR
    A["Raw extract\n(1,200 rows x 18 cols)"] --> B["Drop columns\n>50% missing"]
    B --> C["Impute gaps\ngrouped median / mode"]
    C --> D["Cap outliers\nIQR x 1.5"]
    D --> E["Scale features\nMin-Max + Standard"]
    E --> F["logistics_clean.csv\n0 missing - 0 raw outliers"]

    style A fill:#0A3A3D,stroke:#C9A227,color:#fff
    style F fill:#0F5257,stroke:#C9A227,color:#fff
    style B fill:#123C3E,stroke:#7FB3AE,color:#fff
    style C fill:#123C3E,stroke:#7FB3AE,color:#fff
    style D fill:#123C3E,stroke:#7FB3AE,color:#fff
    style E fill:#123C3E,stroke:#7FB3AE,color:#fff
```

## Proof of execution

Real console output from a pipeline run — `df.isnull().sum()` before cleaning (18 columns, several with real gaps) and after (16 columns, zero nulls anywhere):

<img src="terminal_screenshot.png" width="620" alt="Real terminal output of the pipeline run"/>

Full raw log: [`run_output.txt`](run_output.txt) · Executed notebook with the same output inline: [`notebooks/week2_data_cleaning_preprocessing.ipynb`](notebooks/week2_data_cleaning_preprocessing.ipynb)

## Repository structure

| Path | What it is |
|---|---|
| `generate_sample_data.py` | Builds the representative sample CSV with real injected data-quality issues |
| `preprocessing.py` | The full pipeline (script form) — run this |
| `notebooks/week2_data_cleaning_preprocessing.ipynb` | Same pipeline, cell-by-cell, **already executed** with real inline output |
| `data/dataco_supply_chain_sample.csv` | Input sample |
| `data/logistics_clean.csv` | Pipeline output |
| `terminal_screenshot.png` | Rendered proof of a real run |
| `run_output.txt` | Full raw console log |

## Run it

```bash
pip install -r requirements.txt
python3 generate_sample_data.py   # (re)generate the sample data
python3 preprocessing.py          # run the pipeline; prints before/after stats
```

Or open the notebook for the annotated, cell-by-cell walkthrough.

<details>
<summary><strong>Cleaning techniques used, and why</strong> (click to expand)</summary>

<br/>

| Technique | Why chosen | Effect on downstream analysis |
|---|---|---|
| Drop columns >50% missing | Avoids inventing data where almost none exists | Prevents imputation noise from diluting model signal |
| Grouped median imputation | Median resists skew; grouping respects operational context (shipping mode) | Keeps shipping-time distributions realistic per mode |
| IQR-based capping (1.5x) | Robust to right-skewed financial data; retains all rows | Prevents a handful of extreme orders from dominating regression/clustering |
| Min-Max scaling | Bounds features to [0, 1] for distance-based algorithms | No feature dominates k-means/kNN purely due to raw scale |
| Standard scaling | Centers/normalizes for Gaussian-assuming algorithms | Improves convergence and coefficient interpretability in linear regression |

</details>

---

<div align="center">
<sub>Full methodology write-up, rationale, and before/after impact analysis in the accompanying Week 2 report.</sub>
</div>
