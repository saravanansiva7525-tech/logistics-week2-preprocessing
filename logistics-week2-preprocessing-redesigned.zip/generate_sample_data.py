"""
Generates a representative SAMPLE of the DataCo Smart Supply Chain schema.

Note: this is a synthetic sample (not a scrape of the real Kaggle dataset —
Kaggle requires authenticated download). It mirrors the real dataset's
column names, dtypes, and realistic data-quality problems (missing values,
outliers, mixed scales) so the cleaning pipeline in preprocessing.py runs
against genuinely messy data and produces real, reproducible output.

To use the ACTUAL full dataset instead: download from
https://www.kaggle.com/datasets/shashwatwork/dataco-smart-supply-chain-for-big-data-analysis
and place it at data/dataco_supply_chain.csv, then run preprocessing.py.
"""
import numpy as np
import pandas as pd

rng = np.random.default_rng(42)
N = 1200

shipping_modes = ["Standard Class", "First Class", "Second Class", "Same Day"]
delivery_status = ["Shipped", "Delivered", "In Transit", "Late delivery"]
categories = ["Electronics", "Apparel", "Home & Garden", "Sporting Goods", "Toys", "Office Supplies"]
countries = ["USA", "Mexico", "Germany", "Brazil", "India", "France", "Australia"]
cities = ["New York", "Mexico City", "Berlin", "Sao Paulo", "Mumbai", "Paris", "Sydney"]

order_date = pd.to_datetime("2023-01-01") + pd.to_timedelta(
    rng.integers(0, 730, N), unit="D"
)
shipping_mode = rng.choice(shipping_modes, N, p=[0.55, 0.2, 0.15, 0.1])

# baseline scheduled days per mode
sched_map = {"Standard Class": 5, "First Class": 2, "Second Class": 3, "Same Day": 1}
days_sched = np.array([sched_map[m] for m in shipping_mode])
days_real = days_sched + rng.normal(0, 1.3, N).round().astype(int)
days_real = np.clip(days_real, 0, None)

sales = rng.gamma(shape=2.0, scale=90, size=N).round(2)
quantity = rng.integers(1, 8, N)
profit = (sales * rng.normal(0.12, 0.08, N)).round(2)

df = pd.DataFrame({
    "Order Id": np.arange(100000, 100000 + N),
    "Order Date": order_date,
    "Shipping Mode": shipping_mode,
    "Days for shipment (scheduled)": days_sched,
    "Days for shipping (real)": days_real.astype(float),
    "Delivery Status": rng.choice(delivery_status, N, p=[0.2, 0.55, 0.15, 0.1]),
    "Late_delivery_risk": (days_real > days_sched).astype(int),
    "Category Name": rng.choice(categories, N),
    "Order Item Quantity": quantity,
    "Sales": sales,
    "Order Profit Per Order": profit,
    "Customer City": rng.choice(cities, N),
    "Customer Country": rng.choice(countries, N),
    "Order City": rng.choice(cities, N),
    "Order Country": rng.choice(countries, N),
    "Customer Zipcode": rng.integers(10000, 99999, N).astype(float),
    "Order Zipcode": rng.integers(10000, 99999, N).astype(float),
    "Product Description": [np.nan] * N,  # fully null column, as in the real dataset
})

# --- inject realistic missingness ---
# Order Zipcode: structurally sparse (>80% missing), mirrors real dataset behavior
mask = rng.random(N) < 0.86
df.loc[mask, "Order Zipcode"] = np.nan

# Customer Zipcode: sparse missing (~1.5%)
mask = rng.random(N) < 0.015
df.loc[mask, "Customer Zipcode"] = np.nan

# Days for shipping (real): a few cancelled/null orders (~1%)
mask = rng.random(N) < 0.01
df.loc[mask, "Days for shipping (real)"] = np.nan

# --- inject realistic outliers ---
outlier_idx = rng.choice(N, size=14, replace=False)
df.loc[outlier_idx[:7], "Sales"] = df["Sales"].max() * rng.uniform(6, 12, 7)
df.loc[outlier_idx[7:], "Order Profit Per Order"] = df["Order Profit Per Order"].std() * rng.choice(
    [-1, 1], 7
) * rng.uniform(15, 25, 7)

df.to_csv("data/dataco_supply_chain_sample.csv", index=False)
print(f"Sample written: {df.shape[0]} rows, {df.shape[1]} columns")
print(f"-> data/dataco_supply_chain_sample.csv")
