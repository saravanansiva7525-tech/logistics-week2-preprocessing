from PIL import Image, ImageDraw, ImageFont

with open("run_output.txt") as f:
    lines = f.read().splitlines()

def slice_between(lines, start_marker, end_marker=None):
    out = []
    capture = False
    for l in lines:
        if start_marker in l:
            capture = True
        if capture:
            out.append(l)
        if end_marker and end_marker in l and capture:
            break
    return out

raw_section = slice_between(lines, "STEP 1: RAW DATA INSPECTION", "STEP 2:")[:-1]
final_section = slice_between(lines, "Final missing-value check:")

display_lines = (
    ["$ python3 preprocessing.py", ""]
    + raw_section
    + ["", "..."]
    + final_section
)

font_path = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"
font_size = 17
font = ImageFont.truetype(font_path, font_size)
title_font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf", 15)

TEAL_DARK = "#0A3A3D"
TEAL_BG = "#0D2F31"
GOLD = "#C9A227"
TITLEBAR = "#123C3E"

pad_x, pad_y = 26, 24
line_h = 24
top_bar_h = 42

width = 860
height = top_bar_h + pad_y * 2 + line_h * len(display_lines)

img = Image.new("RGB", (width, height), TEAL_BG)
draw = ImageDraw.Draw(img)

# title bar
draw.rectangle([0, 0, width, top_bar_h], fill=TITLEBAR)
for i, (cx, color) in enumerate([(20, "#E0895A"), (44, GOLD), (68, "#7FB3AE")]):
    draw.ellipse([cx - 6, top_bar_h / 2 - 6, cx + 6, top_bar_h / 2 + 6], fill=color)
draw.text((width / 2 - 100, 12), "terminal — preprocessing.py", font=title_font, fill="#CFE3E1")
draw.rectangle([0, top_bar_h, width, top_bar_h + 2], fill=GOLD)

y = top_bar_h + pad_y
for line in display_lines:
    color = "#E7F3F1"
    if line.startswith("$"):
        color = "#E0C25A"
    elif line.strip().startswith("="):
        color = GOLD
    elif "STEP" in line:
        color = "#7FD8C6"
    elif ":" in line and any(ch.isdigit() for ch in line) and "Shape" not in line:
        color = "#E8B96A"
    draw.text((pad_x, y), line, font=font, fill=color)
    y += line_h

img.save("terminal_screenshot.png")
print("saved terminal_screenshot.png", img.size)
