from PIL import Image, ImageDraw, ImageFont

W, H = 1280, 320
TEAL_DARK = "#0A3A3D"
TEAL = "#0F5257"
GOLD = "#C9A227"
PAPER = "#F5F1E8"

img = Image.new("RGB", (W, H), TEAL_DARK)
draw = ImageDraw.Draw(img)

# subtle diagonal accent band
for i in range(0, W + H, 14):
    draw.line([(i, 0), (i - H, H)], fill="#0D4548", width=6)

# re-cover with a solid panel on the left for text (keeps texture on the right only)
draw.rectangle([0, 0, int(W * 0.62), H], fill=TEAL_DARK)

# gold rule
draw.rectangle([70, 96, 74, H - 96], fill=GOLD)

serif_bold = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf", 40)
serif = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf", 22)
mono = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", 18)

draw.text((100, 88), "WEEK 2 · LOGISTICS ANALYTICS", font=mono, fill=GOLD)
draw.text((100, 122), "Data Collection, Cleaning &", font=serif_bold, fill="#FFFFFF")
draw.text((100, 172), "Preprocessing Pipeline", font=serif_bold, fill="#FFFFFF")
draw.text((100, 226), "pandas  ·  scikit-learn  ·  IQR outlier capping  ·  feature scaling", font=serif, fill="#BFDAD8")

# small badge circle motif on the right (abstract pipeline dots, connected by a line)
cx, cy = 980, 160
nodes = [
    (-260, -40, 26, GOLD), (-140, 30, 20, "#7FB3AE"), (-10, -60, 22, "#FFFFFF"),
    (110, 10, 26, GOLD), (240, -30, 18, "#7FB3AE"),
]
centers = [(cx + dx, cy + dy) for dx, dy, r, col in nodes]
for (x1, y1), (x2, y2) in zip(centers, centers[1:]):
    draw.line([x1, y1, x2, y2], fill="#3E6C6A", width=3)
for (x, y), (dx, dy, r, col) in zip(centers, nodes):
    draw.ellipse([x - r, y - r, x + r, y + r], outline=col, width=4)

img.save("assets/banner.png")
print("saved", img.size)
